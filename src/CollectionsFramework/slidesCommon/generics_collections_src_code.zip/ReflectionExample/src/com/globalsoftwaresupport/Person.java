package com.globalsoftwaresupport;

public class Person {
	
	private String name;
	public int age;
}
