package com.globalsoftwaresupport;

public interface Vehicle {

}
