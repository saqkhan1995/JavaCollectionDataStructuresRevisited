package com.globalsoftwaresupport;

public class Test {

	private Test() {
		
	}

	@Override
	public String toString() {
		return "This is a Test object...";
	}
	
	
}
