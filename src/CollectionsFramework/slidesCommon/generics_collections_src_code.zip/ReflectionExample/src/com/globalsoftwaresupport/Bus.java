package com.globalsoftwaresupport;

public class Bus implements Vehicle {

}
