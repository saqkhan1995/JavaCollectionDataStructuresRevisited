package com.globalsoftwaresupport;

public class Car implements Vehicle {

}
