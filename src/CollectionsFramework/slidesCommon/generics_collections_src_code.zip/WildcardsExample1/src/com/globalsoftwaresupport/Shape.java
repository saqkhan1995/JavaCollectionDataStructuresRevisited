package com.globalsoftwaresupport;

public interface Shape {
	public void draw();
}
